import java.util.ArrayList;
import java.util.List;
public class Blockchain {
    private List<Block> chain;
    public Blockchain() {
        this.chain = new ArrayList<>();
        addGenesisBlock();
    }

    private void addGenesisBlock() {
        //System.out.println("Am i here");
        Block genesisBlock = new Block(0, "0000000000000000000000000000000000000000000000000000000000000000");
        //System.out.println("Here");
        chain.add(genesisBlock);
        System.out.println("Genesis Block added successfully!");
    }

    public void addBlock(Block block) {
        if (isValidBlock(block)) {
            chain.add(block);
        }
    }

    private boolean isValidBlock(Block block) {
        return block.getPreviousHash().equals(getLatestBlock().getHash());
    }

    public Block getLatestBlock() { return chain.get(chain.size() - 1);}

    public List<Block> getChain() { return chain;}
}